#include "Path.h"

Path::Path(unsigned int l) : length(l) {}

Path::Path(Path& p) : length(p.length) {
  avgRating = p.avgRating;
}

unsigned Path::getPoints() {
  /* your code goes here */
}

void Path::rate(unsigned int rating) {
  /* your code goes here */
}